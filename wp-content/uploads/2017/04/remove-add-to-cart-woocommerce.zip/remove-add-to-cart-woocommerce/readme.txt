=== Remove Add to Cart Woocommerce ===
Contributors: themelocation
Donate link: https://www.paypal.me/themelocation
Tags: Woocommerce, add to cart, inquiry button, remove button
Requires at least: 3.0.1
Tested up to: Wordpress Version 4.7 and Woocommerce Version 2.6.12
Stable Tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


How to Remove/disable Add to cart And Replace Cart button with Inquiry Us button in Woocommerce.

== Description ==

This Plugin performs following functions; Developed by <a href="https://www.themelocation.com/">themelocation</a>

1- Remove/Disable Add to Cart from Complete Category.<br>
2- Replace Add to Cart button with Inquire Us from Complete Category.<br>
3- Remove Add to cart from individual Product pages.<br>
4- Replace Add to cart with Inquire us from product pages.<br>

This Plugin Work on both Category Level as well as Individual Level. If Store owner do not want add to cart button on Whole category, He can remove that.

If Store Owner wants to remove add to cart from Specific product, he can do that.

Also, If Someone want to replace add to cart with inquiry button he can do that too with this Plugin. 

You can make settings on Category pages and individual Product pages.

<p>If you like the plugin, Please make a small donation <a href="https://www.paypal.me/themelocation" rel="nofollow">donate via PayPal</a>. I'm gladly supporting this plugin! Thanks a lot! :)</p>


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3- Under each product you will see option to configure the plugin.

If You need any Help Simple <a href="http://themelocation.com/contact/">Contact us</a>
